/* 
 * File:   lab2.cpp
 * Author: Jonathan Balisky
 * Created on June 24, 2015, 5:57 PM
 * Purpose:  Lab, Energy Drinkers
 */
 
 #include <iostream>
 using namespace std;
 
 //Global Constants
 
 const float CNVPCT=100.0f; //Conversion to percent
 
 //Execution
 
 int main(int argc, char** argv) {
 	unsigned short cSurv=12467; //Number of customers surveyed
    unsigned short nEDrnks;    //Number of customers drinking 1 or more energy drinks per week
    unsigned short nCDrnks;    //Number of energy drinkers that prefer citrus flavor
    unsigned char pEDrnks=14;  //Percentage surveyed that prefer energy drinks
    unsigned char pCDrnks=64;  //Percentage of energy drinkers that prefer citrus flavor
    //Calc the number of drinkers
    nEDrnks=cSurv*pEDrnks/CNVPCT;
    nCDrnks=nEDrnks*pCDrnks/CNVPCT;
    
    //calc the results
    cout<<"Number of Energy Drinkers = "<<nEDrnks<<endl;
    cout<<"Number of Citrus Drinkers = "<<nCDrnks<<endl;
     //Exit the stage!
    return 0;
 }
