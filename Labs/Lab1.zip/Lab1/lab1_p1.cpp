/* 
File: main.cpp
Author: Jonathan Balisky
Created on June 23, 2015, 12:35pm
Purpose: First Program to test the IDE
*/

//System Libraries
#include <iostream>
using namespace std;

//User Libraires

//Global constants

//Function Prototypes

//Excution Begins Here!
int main(int argc, char** argv){
	//Declare Variables 
	
	//Input Values
	
	//Output Unknowns
	
	cout<<"Hello world!!!!"<<endl;
	//Exit 
	return 0;
}
